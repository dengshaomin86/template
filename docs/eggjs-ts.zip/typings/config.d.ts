import "egg";

declare module "egg" {
  interface EggConfig {
    defaultAvatar: string;
  }
}
