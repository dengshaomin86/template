/**
 * account types
 */

export interface CreateAccountRequest {
  mainstay: string;
}

export interface CreateAccount extends CreateAccountRequest {
  userId: string;
}

export interface ListRequest {
  pageNum: number;
  pageSize: number;
}

export interface ListQuery extends ListRequest {
  userId: number;
}

export interface Account {
  id: string;
  mainstay: string;
}

export interface List {
  list: Account[];
  total: number;
  pageNum: number;
  pageSize: number;
}
