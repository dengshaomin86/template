/**
 * user types
 */

export interface CreateUserRequest {
  username: string;
  password: string;
  cPassword: string;
}

export interface User {
  userId: string;
  username: string;
  password: string;
  avatar: string;
  nickname: string;
  sex: string;
  hobby: string;
  email: string;
  publicKey: string;
  createDate: Date;
}

export type UserInfo = Omit<User, "password" | "publicKey">;
