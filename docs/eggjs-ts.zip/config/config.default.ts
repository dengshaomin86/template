import { EggAppConfig, EggAppInfo, PowerPartial } from "egg";

export default (appInfo: EggAppInfo) => {
  const config = {} as PowerPartial<EggAppConfig>;

  // 多进程模型的启动模式
  config.cluster = {
    listen: {
      port: 7002,
      hostname: "0.0.0.0", // 不建议设置 hostname 为 '0.0.0.0'，它将允许来自外部网络和来源的连接，请在知晓风险的情况下使用
    },
  };

  // override config from framework / plugin
  // use for cookie sign key, should change to your own and keep security
  config.keys = appInfo.name + "_1724461580083_6098";

  // add your egg config in here
  config.middleware = ["errorHandler", "responseFormat"];

  // add your special config in here
  const bizConfig = {
    sourceUrl: `https://github.com/eggjs/examples/tree/master/${appInfo.name}`,
  };

  config.security = {
    csrf: {
      enable: false,
      useSession: true, // 默认为 false，当设置为 true 时，将把 csrf token 保存到 Session 中
      cookieName: "csrfToken", // Cookie 中的字段名，默认为 csrfToken
      sessionName: "csrfToken", // Session 中的字段名，默认为 csrfToken
    },
    domainWhiteList: ["*"],
  };

  config.cors = {
    origin: ["*"],
    credentials: true,
    allowMethods: "GET,HEAD,PUT,POST,DELETE,PATCH,OPTIONS",
  };

  /**
   * session
   * @type {{key: string, maxAge: number, httpOnly: boolean, encrypt: boolean, renew: boolean}}
   * renew 等于 true 那么每次请求的时候 session 都会被延期
   */
  config.session = {
    key: "SESSION_ID",
    maxAge: 1000 * 60 * 30,
    httpOnly: true,
    encrypt: true,
    renew: true,
  };

  // mongodb config
  config.mongoose = {
    client: {
      url: "mongodb://127.0.0.1:27017/service-demo",
      options: {
        // useUnifiedTopology: true,
        // useCreateIndex: true,
        // useFindAndModify: false,
      },
    },
  };

  // the return config will combines to EggAppConfig
  return {
    defaultAvatar: "default-avatar-url",
    ...config,
    ...bizConfig,
  };
};
