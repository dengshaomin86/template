import { Schema, model, Model, Document } from "mongoose";
import { v4 as uuidv4 } from "uuid";
import bcrypt from "bcrypt";

// Define the interface for the user document
export interface IUser extends Document {
  userId: string;
  username: string;
  password: string;
  avatar: string;
  nickname: string;
  sex: string;
  hobby: string;
  email: string;
  publicKey: string;
  createDate: Date;
  // Method to compare hashed password with a plain text password
  comparePassword(password: string): Promise<boolean>;
}

// Define the schema for the user model
const UserSchema = new Schema<IUser>({
  userId: { type: String, required: true, unique: true },
  username: { type: String, unique: true, required: true, minlength: 2, maxlength: 10 },
  password: { type: String, required: true, minlength: 6, maxlength: 200 },
  avatar: { type: String, default: "" },
  nickname: { type: String, default: "" },
  sex: { type: String, default: "0" },
  hobby: { type: String, default: "" },
  email: { type: String, default: "" },
  publicKey: { type: String, default: "" },
  createDate: { type: Date, default: () => new Date() },
});

// 如果你需要对字段进行频繁的查询（如 username 或 email），可以为这些字段添加索引以提高查询性能
UserSchema.index({ username: 1 });

// pre-save 预保存钩子，在保存之前生成自定义唯一 ID。注意: 文档字段校验在他之前，所以要保证数据源完整
UserSchema.pre<IUser>("save", async function (next) {
  if (this.isNew) {
    this.userId = uuidv4(); // 生成唯一 ID
  }
  if (this.isModified("password")) {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
  }
  next();
});

// Compare hashed password with plain text password
UserSchema.methods.comparePassword = async function (password: string): Promise<boolean> {
  return bcrypt.compare(password, this.password);
};

// Define and export the model
const UserModel: Model<IUser> = model<IUser>("User", UserSchema, "users");
export default UserModel;
