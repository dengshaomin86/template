import { Schema, model, Document } from "mongoose";
import { v4 as uuidv4 } from "uuid";

// Define the interface for the document
export interface IAccount extends Document {
  userId: string;
  id: string;
  mainstay: string;
  createTime: Date;
  modifyTime: Date;
}

// Define the schema for the model
const AccountSchema = new Schema<IAccount>({
  id: { type: String, required: true, unique: true },
  userId: { type: String, required: true },
  mainstay: { type: String, required: true },
  createTime: Date,
  modifyTime: Date,
});

// 如果你需要对字段进行频繁的查询（如 username 或 email），可以为这些字段添加索引以提高查询性能
AccountSchema.index({ id: 1 });
AccountSchema.index({ userId: 1 });

// 在保存之前生成自定义唯一 ID
AccountSchema.pre<IAccount>("save", function (next) {
  if (this.isNew) {
    this.id = uuidv4(); // 生成唯一 ID
  }
  next();
});

// Define and export the model
export default model<IAccount>("Account", AccountSchema, "accounts");
