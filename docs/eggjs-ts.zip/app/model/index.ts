import { Application } from "egg";
import UserModel from "./user";
import AccountModel from "./account";

export default (app: Application) => {
  app.model = {
    User: UserModel,
    Account: AccountModel,
  };
};
