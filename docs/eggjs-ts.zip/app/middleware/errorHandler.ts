import { Context } from "egg";

export default function errorHandler() {
  return async (ctx: Context, next: () => Promise<any>) => {
    try {
      await next();
    } catch (err: any) {
      // Log the error (you might want to use a logger here)
      ctx.app.logger.error(err);

      // Set the response status code
      ctx.status = err.status || 500;

      // Return a consistent error response format
      ctx.body = {
        success: false,
        message: err.message || "Internal Server Error",
        ...(ctx.app.config.env === "development" && {
          // Include stack trace in development
          stack: err.stack,
        }),
      };
    }
  };
}
