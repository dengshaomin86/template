import { Context } from "egg";
import { EggLogger } from "egg";

const whiteList = ["/", "/about", "/user/signUp", "/user/signIn"];

export default function auth() {
  return async (ctx: Context, next: () => Promise<any>) => {
    const logger: EggLogger = ctx.app.logger;

    if (whiteList.includes(ctx.request.url)) {
      await next();
      return;
    }

    const userId = ctx.session.userId;

    if (!userId) {
      ctx.status = 401;
      ctx.body = {
        success: false,
        message: "请先登录",
      };
      return;
    }

    await next();
  };
}
