import { Context } from "egg";
import { EggLogger } from "egg";

export default function responseFormat() {
  return async (ctx: Context, next: () => Promise<any>) => {
    await next();

    const logger: EggLogger = ctx.app.logger;

    // 仅处理非错误响应
    if (ctx.status >= 200 && ctx.status < 300) {
      let data: any = null;
      if (typeof ctx.body === "object" && ctx.body !== null && !Array.isArray(ctx.body)) {
        data = ctx.body;
      } else {
        data = { data: ctx.body };
      }
      ctx.body = { success: true, ...data };
    }
  };
}
