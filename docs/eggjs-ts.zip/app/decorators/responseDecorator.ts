// app/decorators/responseDecorator.ts

import { Context } from "egg";

export function Response() {
  return function (target: any, propertyKey: string, descriptor: PropertyDescriptor) {
    const method = descriptor.value;

    descriptor.value = async function (...args: any[]) {
      // @ts-ignore
      const ctx: Context = this.ctx;

      const result = await method.apply(this, args);

      ctx.body = {
        success: true,
        data: result,
      };
    };
  };
}
