import { CustomError } from "app/errors/customError";
import { HTTP_STATUS_CODES, ERROR_CODES } from "app/constants/errorCodes";

export function Auth() {
  return function (target: any, propertyKey: string, descriptor: PropertyDescriptor) {
    const method = descriptor.value;

    descriptor.value = async function (...args: any[]) {
      // @ts-ignore
      if (!this.session.userId) {
        throw new CustomError(`请先登录`, HTTP_STATUS_CODES.UNAUTHORIZED, ERROR_CODES.UNAUTHORIZED);
      }

      return method.apply(this, args);
    };
  };
}
