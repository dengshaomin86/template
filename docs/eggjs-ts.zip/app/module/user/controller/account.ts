import { EggLogger } from "egg";
import { Inject, HTTPController, HTTPMethod, HTTPMethodEnum, HTTPBody, HTTPQuery } from "@eggjs/tegg";
import { Auth } from "app/decorators/auth";
import type { AccountService } from "@/module/user";
import type { CreateAccountRequest } from "typings/user/account-types";

@HTTPController({
  path: "/account",
})
export class AccountController {
  @Inject()
  logger: EggLogger;

  @Inject()
  accountService: AccountService;

  @Inject()
  session: { [key: string]: any };

  @HTTPMethod({
    method: HTTPMethodEnum.POST,
    path: "create",
  })
  @Auth()
  async create(@HTTPBody() body: CreateAccountRequest) {
    try {
      const { userId } = this.session;
      const result = await this.accountService.create({ ...body, userId });
      return { data: result, message: "创建成功" };
    } catch (err) {
      throw err;
    }
  }

  @HTTPMethod({
    method: HTTPMethodEnum.GET,
    path: "list",
  })
  @Auth()
  async list(@HTTPQuery() pageNum: number, @HTTPQuery() pageSize: number) {
    try {
      const { userId } = this.session;
      const data = await this.accountService.list({ userId, pageNum, pageSize });
      return data;
    } catch (err) {
      throw err;
    }
  }

  @HTTPMethod({
    method: HTTPMethodEnum.GET,
    path: "detail",
  })
  @Auth()
  async detail(@HTTPQuery() id: string) {
    try {
      const { userId } = this.session;
      const data = await this.accountService.detail({ userId, id });
      return { data };
    } catch (err) {
      throw err;
    }
  }
}
