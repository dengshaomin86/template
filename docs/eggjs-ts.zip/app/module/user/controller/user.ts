import { Inject, HTTPController, HTTPMethod, HTTPMethodEnum, HTTPBody } from "@eggjs/tegg";
import { EggLogger } from "egg";
import type { UserService } from "@/module/user";
import type { CreateUserRequest } from "typings/user/user-types";

@HTTPController({
  path: "/user",
})
export class UserController {
  @Inject()
  logger: EggLogger;

  @Inject()
  userService: UserService;

  @Inject()
  session: { [key: string]: any };

  @HTTPMethod({
    method: HTTPMethodEnum.POST,
    path: "signUp",
  })
  async signUp(@HTTPBody() body: CreateUserRequest) {
    try {
      const user = await this.userService.signUp(body);
      return { data: user, message: "注册成功" };
    } catch (err) {
      throw err;
    }
  }

  @HTTPMethod({
    method: HTTPMethodEnum.POST,
    path: "signIn",
  })
  async signIn(@HTTPBody() body: CreateUserRequest) {
    try {
      const user = await this.userService.signIn(body);
      this.session.usename = user.username;
      this.session.userId = user.userId;
      return { data: user, message: "登录成功" };
    } catch (err) {
      throw err;
    }
  }
}
