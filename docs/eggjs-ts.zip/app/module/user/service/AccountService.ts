import { pick } from "lodash";
import { EggLogger } from "egg";
import { SingletonProto, AccessLevel, Inject } from "@eggjs/tegg";
import { CreateAccount, ListQuery, Account, List } from "typings/user/account-types";
import AccountModel, { IAccount } from "app/model/account";
import { CustomError } from "app/errors/customError";
import { ERROR_CODES, HTTP_STATUS_CODES } from "app/constants/errorCodes";

@SingletonProto({
  // 如果需要在上层使用，需要把 accessLevel 显示声明为 public
  accessLevel: AccessLevel.PUBLIC,
})
export class AccountService {
  @Inject()
  logger: EggLogger;

  Account = AccountModel;

  /**
   * 校验
   * @param body
   */
  validateData(body: CreateAccount) {
    const { mainstay } = body;

    if (!mainstay) {
      throw new CustomError("内容不能为空", HTTP_STATUS_CODES.BAD_REQUEST, ERROR_CODES.COMMON_ERROR);
    }
  }

  /**
   * 格式化
   * @param data
   * @returns
   */
  formatData(data: IAccount) {
    return pick(data, ["id", "mainstay"]);
  }

  // 封装业务
  async create(body: CreateAccount): Promise<Account> {
    // 校验数据
    this.validateData(body);

    // 创建
    const data = new AccountModel({ ...body, id: "0" });
    await data.save();

    return this.formatData(data);
  }

  async list(params: ListQuery): Promise<List> {
    const { userId, pageNum, pageSize } = params;
    const skip = (pageNum - 1) * pageSize;
    const list = await this.Account.find({ userId }).skip(skip).limit(pageSize).exec();
    const total = await this.Account.countDocuments().exec();
    return { list: list.map((v) => this.formatData(v)), total, pageNum, pageSize };
  }

  async detail(params: { userId: string; id: string }): Promise<Account | null> {
    const { userId, id } = params;
    const list = await this.Account.find({ userId, id });
    return list[0] ? this.formatData(list[0]) : null;
  }
}
