import { pick } from "lodash";
import { EggLogger } from "egg";
import { SingletonProto, AccessLevel, Inject } from "@eggjs/tegg";
import { CustomError } from "app/errors/customError";
import { HTTP_STATUS_CODES, ERROR_CODES } from "app/constants/errorCodes";
import UserModel, { IUser } from "app/model/user";
import type { CreateUserRequest, UserInfo } from "typings/user/user-types";
import type { EggConfig } from "typings/app";

@SingletonProto({
  // 如果需要在上层使用，需要把 accessLevel 显示声明为 public
  accessLevel: AccessLevel.PUBLIC,
})
export class UserService {
  @Inject()
  logger: EggLogger;

  @Inject()
  config: EggConfig; // 注入配置对象

  User = UserModel;

  /**
   * 校验密码
   * @param username
   * @param password
   * @returns
   */
  async authenticateUser(username: string, password: string): Promise<false | UserInfo> {
    const user = await UserModel.findOne({ username });
    if (!user) {
      throw new CustomError(`用户不存在`, HTTP_STATUS_CODES.BAD_REQUEST, ERROR_CODES.USER_NOT_EXIST);
    }
    return (await user.comparePassword(password)) && this.formatUser(user);
  }

  /**
   * 格式化输出用户信息
   * @param user
   * @returns
   */
  formatUser(user: IUser): UserInfo {
    return pick(user, ["userId", "username", "avatar", "nickname", "sex", "hobby", "email", "createDate"]);
  }

  /**
   * 查找用户
   * @param username
   * @returns
   */
  async findUser(username: string): Promise<UserInfo | null> {
    const user = await UserModel.findOne({ username });
    if (!user) return null;
    return this.formatUser(user);
  }

  /**
   * 校验用户注册数据
   * @param body
   */
  private async validateUserRegistration(body: CreateUserRequest): Promise<void> {
    const { username, password, cPassword } = body;

    // 1. 校验用户名是否重复
    const existingUser = await UserModel.findOne({ username });
    if (existingUser) {
      throw new CustomError("用户名已存在", HTTP_STATUS_CODES.BAD_REQUEST, ERROR_CODES.USERNAME_ALREADY_EXISTS);
    }

    // 2. 校验用户名长度
    const usernameField = UserModel.schema.path("username");
    const { minlength: uMin = 6, maxlength: uMax = 100 } = usernameField.options || {};
    if (username.length < uMin) {
      throw new CustomError(`用户名长度不能小于${uMin}`, HTTP_STATUS_CODES.BAD_REQUEST, ERROR_CODES.USERNAME_TOO_SHORT);
    }
    if (username.length > uMax) {
      throw new CustomError(`用户名长度不能大于${uMax}`, HTTP_STATUS_CODES.BAD_REQUEST, ERROR_CODES.USERNAME_TOO_LONG);
    }

    // 3. 校验密码长度
    const passwordField = UserModel.schema.path("password");
    const { minlength = 6, maxlength = 100 } = passwordField.options || {};
    if (password.length < minlength) {
      throw new CustomError(`密码长度不能小于${minlength}`, HTTP_STATUS_CODES.BAD_REQUEST, ERROR_CODES.PASSWORD_TOO_SHORT);
    }
    if (password.length > maxlength) {
      throw new CustomError(`密码长度不能大于${maxlength}`, HTTP_STATUS_CODES.BAD_REQUEST, ERROR_CODES.PASSWORD_TOO_LONG);
    }

    // 4. 校验密码是否一致
    if (password !== cPassword) {
      throw new CustomError(`密码不一致`, HTTP_STATUS_CODES.BAD_REQUEST, ERROR_CODES.PASSWORD_DIFFERENT);
    }
  }

  /**
   * 注册
   * mongoose 校验在 pre-save 钩子前，userId 需要给个默认值，否则报错
   * @param body
   * @returns
   */
  async signUp(body: CreateUserRequest): Promise<UserInfo> {
    // 校验用户注册数据
    await this.validateUserRegistration(body);

    // 创建用户
    const user = new UserModel({ ...body, userId: "0", avatar: this.config.defaultAvatar });
    await user.save();

    return this.formatUser(user);
  }

  /**
   * 登录
   * @param body
   * @returns
   */
  async signIn(body: CreateUserRequest): Promise<UserInfo> {
    const { username, password } = body;

    // 校验密码
    const user = await this.authenticateUser(username, password);

    if (user === false) {
      throw new CustomError(`密码错误`, HTTP_STATUS_CODES.BAD_REQUEST, ERROR_CODES.PASSWORD_WRONG);
    }

    return user;
  }
}
