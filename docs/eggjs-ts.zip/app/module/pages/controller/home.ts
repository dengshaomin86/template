import { EggLogger } from "egg";
import { Inject, HTTPController, HTTPMethod, HTTPMethodEnum, HTTPQuery } from "@eggjs/tegg";
import { HelloService } from "@/module/pages";

@HTTPController({
  path: "/",
})
export class HomeController {
  @Inject()
  logger: EggLogger;

  @Inject()
  helloService: HelloService;

  @HTTPMethod({
    method: HTTPMethodEnum.GET,
    path: "/",
  })
  async index() {
    this.logger.info("hello egg logger");
    return "hello egg";
  }

  @HTTPMethod({
    method: HTTPMethodEnum.GET,
    path: "about",
  })
  async about(@HTTPQuery({ name: "q" }) q: string) {
    return await this.helloService.hello(q);
  }
}
