import path from "path";

console.log("preload", path.join("d:/", "a"));
