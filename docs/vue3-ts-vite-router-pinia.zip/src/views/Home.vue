<template>
  <div>
    <h1>Home</h1>
    <RouterList />
  </div>
</template>

<script setup lang="ts">
import RouterList from "@/components/RouterList.vue";
</script>

<style lang="scss" scoped></style>
